# SuperIncert (by Incertus)
Tap an icon -> choose the widget shape -> choose the app it opens -> it is added to the home screen.
Widgets are resizable: the icon is redrawn at the exact size.

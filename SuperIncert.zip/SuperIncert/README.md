# SuperIncert (by Incertus)
HyperOS-style widgets. Tap an icon -> choose the shape -> choose the app it opens -> it is added to the home screen.

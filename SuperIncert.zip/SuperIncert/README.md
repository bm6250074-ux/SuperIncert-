# SuperIncert (by Incertus)
Home-screen widgets app. Tap a widget in the app → choose the app it opens → it is added to your home screen.

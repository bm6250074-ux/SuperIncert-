package com.incertus.superincert

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ListView
import android.widget.TextView

class AppItem(val pkg: String, val label: String, val icon: Drawable)

object AppPicker {
    fun show(act: Activity, iconRes: Int, onPick: (String) -> Unit, onCancel: () -> Unit) {
        val density = act.resources.displayMetrics.density
        fun dp(v: Int): Int = (v * density + 0.5f).toInt()

        val pm = act.packageManager
        val main = Intent(Intent.ACTION_MAIN)
        main.addCategory(Intent.CATEGORY_LAUNCHER)
        val all: List<AppItem> = pm.queryIntentActivities(main, 0)
            .filter { it.activityInfo.packageName != act.packageName }
            .distinctBy { it.activityInfo.packageName }
            .map { AppItem(it.activityInfo.packageName, it.loadLabel(pm).toString(), it.loadIcon(pm)) }
            .sortedBy { it.label.lowercase() }
        val shown = ArrayList<AppItem>(all)

        val root = LinearLayout(act)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(14), dp(16), dp(4))

        val head = LinearLayout(act)
        head.orientation = LinearLayout.HORIZONTAL
        head.gravity = Gravity.CENTER_VERTICAL
        val prev = ImageView(act)
        prev.setImageResource(iconRes)
        prev.scaleType = ImageView.ScaleType.FIT_CENTER
        head.addView(prev, LinearLayout.LayoutParams(dp(48), dp(48)))
        val ttl = TextView(act)
        ttl.text = "اختر التطبيق الذي سيفتحه هذا الويدجيت"
        ttl.textSize = 16f
        ttl.setTextColor(Color.WHITE)
        ttl.setPadding(dp(12), 0, dp(4), 0)
        head.addView(ttl, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        root.addView(head, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val search = EditText(act)
        search.hint = "ابحث عن تطبيق..."
        search.setSingleLine(true)
        search.setTextColor(Color.WHITE)
        search.setHintTextColor(0x88FFFFFF.toInt())
        val sLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        sLp.topMargin = dp(8)
        root.addView(search, sLp)

        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = shown.size
            override fun getItem(position: Int): Any = shown[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val row = LinearLayout(act)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(6), dp(8), dp(6), dp(8))
                val icon = ImageView(act)
                icon.setImageDrawable(shown[position].icon)
                row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
                val tv = TextView(act)
                tv.text = shown[position].label
                tv.textSize = 16f
                tv.setTextColor(Color.WHITE)
                tv.setPadding(dp(14), 0, 0, 0)
                row.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                return row
            }
        }
        val list = ListView(act)
        list.divider = null
        list.adapter = adapter
        val listH = (act.resources.displayMetrics.heightPixels * 0.5f).toInt()
        root.addView(list, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, listH))

        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                val q = (s ?: "").toString().trim().lowercase()
                shown.clear()
                for (a in all) {
                    if (q.isEmpty() || a.label.lowercase().contains(q)) shown.add(a)
                }
                adapter.notifyDataSetChanged()
            }
            override fun afterTextChanged(s: Editable?) {}
        })

        var finished = false
        val dialog = AlertDialog.Builder(act, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setView(root)
            .setNegativeButton("إلغاء") { _, _ ->
                if (!finished) {
                    finished = true
                    onCancel()
                }
            }
            .setOnCancelListener {
                if (!finished) {
                    finished = true
                    onCancel()
                }
            }
            .create()
        list.setOnItemClickListener { _, _, pos, _ ->
            if (!finished) {
                finished = true
                val pkg = shown[pos].pkg
                dialog.dismiss()
                onPick(pkg)
            }
        }
        dialog.show()
    }
}

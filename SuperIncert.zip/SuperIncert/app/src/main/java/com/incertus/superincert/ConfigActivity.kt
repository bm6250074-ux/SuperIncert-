package com.incertus.superincert

import android.app.Activity
import android.appwidget.AppWidgetManager
import android.content.Intent
import android.os.Bundle

/** Opens when a widget is added (or reconfigured) so the user picks the app it opens. */
class ConfigActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val id = intent.getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, AppWidgetManager.INVALID_APPWIDGET_ID)
        setResult(RESULT_CANCELED, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
        if (id == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish()
            return
        }
        val mgr = AppWidgetManager.getInstance(this)
        val typeId = WidgetUtil.typeOf(mgr, id)
        val def = if (typeId == null) null else findShape(typeId)
        if (typeId == null || def == null) {
            finish()
            return
        }
        if (WidgetUtil.consumeFresh(this, typeId, id)) {
            done(id)
            return
        }
        AppPicker.show(this, def.iconRes, { pkg ->
            WidgetUtil.setPkg(this, id, pkg)
            done(id)
        }, {
            finish()
        })
    }

    private fun done(id: Int) {
        WidgetUtil.update(this, AppWidgetManager.getInstance(this), id)
        setResult(RESULT_OK, Intent().putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id))
        finish()
    }
}

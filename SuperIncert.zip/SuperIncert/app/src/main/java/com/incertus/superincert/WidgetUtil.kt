package com.incertus.superincert

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.widget.RemoteViews

object WidgetUtil {
    private fun prefs(c: Context): SharedPreferences =
        c.getSharedPreferences("superincert", Context.MODE_PRIVATE)

    fun typeOf(mgr: AppWidgetManager, id: Int): String? {
        val cn = mgr.getAppWidgetInfo(id)?.provider?.className ?: return null
        return cn.substringAfterLast(".W_")
    }

    fun setPending(c: Context, typeId: String, pkg: String) {
        prefs(c).edit().putString("pending_" + typeId, pkg).apply()
    }

    fun getPkg(c: Context, id: Int): String? = prefs(c).getString("pkg_" + id, null)

    fun setPkg(c: Context, id: Int, pkg: String) {
        prefs(c).edit().putString("pkg_" + id, pkg).apply()
    }

    /** Called from onUpdate: a newly pinned widget takes the app chosen in the app. */
    fun bindPending(c: Context, typeId: String, id: Int) {
        val p = prefs(c)
        if (p.getString("pkg_" + id, null) == null) {
            val pend = p.getString("pending_" + typeId, null)
            if (pend != null) {
                p.edit().putString("pkg_" + id, pend)
                    .putBoolean("fresh_" + id, true)
                    .remove("pending_" + typeId).apply()
            }
        }
    }

    /** Called from the configure screen: true when the app was already chosen in SuperIncert. */
    fun consumeFresh(c: Context, typeId: String, id: Int): Boolean {
        val p = prefs(c)
        if (p.getBoolean("fresh_" + id, false)) {
            p.edit().remove("fresh_" + id).apply()
            return true
        }
        val pend = p.getString("pending_" + typeId, null)
        if (pend != null) {
            p.edit().putString("pkg_" + id, pend).remove("pending_" + typeId).apply()
            return true
        }
        return false
    }

    fun forget(c: Context, ids: IntArray) {
        val e = prefs(c).edit()
        for (id in ids) {
            e.remove("pkg_" + id)
            e.remove("fresh_" + id)
        }
        e.apply()
    }

    fun update(c: Context, mgr: AppWidgetManager, id: Int) {
        val typeId = typeOf(mgr, id) ?: return
        val def = WIDGETS.firstOrNull { it.id == typeId } ?: return
        val rv = RemoteViews(c.packageName, R.layout.widget_icon)
        rv.setImageViewResource(R.id.img, def.iconRes)

        val pkg = getPkg(c, id)
        var intent: Intent? = null
        if (pkg != null) intent = c.packageManager.getLaunchIntentForPackage(pkg)
        if (intent == null) {
            // no app chosen yet (or app removed): tapping lets the user choose
            intent = Intent(c, ConfigActivity::class.java)
            intent.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, id)
        }
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        val pi = PendingIntent.getActivity(
            c, id, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        rv.setOnClickPendingIntent(R.id.root, pi)
        mgr.updateAppWidget(id, rv)
    }
}

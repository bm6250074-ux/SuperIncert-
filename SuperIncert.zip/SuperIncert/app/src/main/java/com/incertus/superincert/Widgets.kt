package com.incertus.superincert

/** One home-screen widget shape. key = group + "_" + shape. */
data class WidgetShape(
    val key: String,
    val shape: String,
    val iconRes: Int,
    val w: Int,      // source image size
    val h: Int,
    val cap: Int,    // corner/cap size that must never be stretched
    val gx0: Int,    // glyph box (never stretched)
    val gy0: Int,
    val gx1: Int,
    val gy1: Int
)

/** One tile in the app: all shapes of the same icon. */
data class WidgetGroup(val id: String, val shapes: List<WidgetShape>)

val GROUPS = listOf(
    WidgetGroup("phone_green_square", listOf(
        WidgetShape("phone_green_square_square", "square", R.drawable.w_phone_green_square_square, 824, 824, 124, 109, 131, 674, 695),
        WidgetShape("phone_green_square_pill", "pill", R.drawable.w_phone_green_square_pill, 996, 399, 199, 353, 63, 623, 336),
        WidgetShape("phone_green_square_vertical", "vertical", R.drawable.w_phone_green_square_vertical, 330, 879, 165, 45, 326, 269, 552)
    )),
    WidgetGroup("phone_green_circle", listOf(
        WidgetShape("phone_green_circle_square", "square", R.drawable.w_phone_green_circle_square, 824, 824, 124, 211, 210, 616, 613),
        WidgetShape("phone_green_circle_pill", "pill", R.drawable.w_phone_green_circle_pill, 996, 399, 199, 399, 101, 597, 297),
        WidgetShape("phone_green_circle_vertical", "vertical", R.drawable.w_phone_green_circle_vertical, 330, 879, 165, 83, 357, 247, 520)
    )),
    WidgetGroup("phone_green_circle2", listOf(
        WidgetShape("phone_green_circle2_square", "square", R.drawable.w_phone_green_circle2_square, 824, 824, 124, 185, 190, 634, 649),
        WidgetShape("phone_green_circle2_pill", "pill", R.drawable.w_phone_green_circle2_pill, 996, 399, 199, 387, 91, 606, 315),
        WidgetShape("phone_green_circle2_vertical", "vertical", R.drawable.w_phone_green_circle2_vertical, 330, 879, 165, 73, 349, 255, 535)
    )),
    WidgetGroup("messages_green", listOf(
        WidgetShape("messages_green_square", "square", R.drawable.w_messages_green_square, 824, 824, 124, 114, 128, 714, 691),
        WidgetShape("messages_green_pill", "pill", R.drawable.w_messages_green_pill, 996, 399, 199, 351, 62, 644, 334),
        WidgetShape("messages_green_vertical", "vertical", R.drawable.w_messages_green_vertical, 330, 879, 165, 44, 325, 287, 550)
    )),
    WidgetGroup("contacts_gray_a", listOf(
        WidgetShape("contacts_gray_a_square", "square", R.drawable.w_contacts_gray_a_square, 824, 824, 124, 212, 116, 610, 500),
        WidgetShape("contacts_gray_a_pill", "pill", R.drawable.w_contacts_gray_a_pill, 996, 399, 199, 401, 56, 593, 236),
        WidgetShape("contacts_gray_a_vertical", "vertical", R.drawable.w_contacts_gray_a_vertical, 330, 879, 165, 85, 320, 244, 475)
    )),
    WidgetGroup("home_blue", listOf(
        WidgetShape("home_blue_square", "square", R.drawable.w_home_blue_square, 824, 824, 124, 131, 120, 691, 682),
        WidgetShape("home_blue_pill", "pill", R.drawable.w_home_blue_pill, 996, 399, 199, 362, 60, 631, 329),
        WidgetShape("home_blue_vertical", "vertical", R.drawable.w_home_blue_vertical, 330, 879, 165, 54, 324, 275, 545)
    )),
    WidgetGroup("apps_blue", listOf(
        WidgetShape("apps_blue_square", "square", R.drawable.w_apps_blue_square, 824, 824, 124, 156, 156, 667, 667),
        WidgetShape("apps_blue_pill", "pill", R.drawable.w_apps_blue_pill, 996, 399, 199, 373, 75, 621, 323),
        WidgetShape("apps_blue_vertical", "vertical", R.drawable.w_apps_blue_vertical, 330, 879, 165, 62, 336, 267, 541)
    )),
    WidgetGroup("apps_orange_circle", listOf(
        WidgetShape("apps_orange_circle_square", "square", R.drawable.w_apps_orange_circle_square, 824, 824, 124, 221, 221, 602, 602),
        WidgetShape("apps_orange_circle_pill", "pill", R.drawable.w_apps_orange_circle_pill, 996, 399, 199, 404, 106, 590, 292),
        WidgetShape("apps_orange_circle_vertical", "vertical", R.drawable.w_apps_orange_circle_vertical, 330, 879, 165, 87, 361, 242, 516)
    )),
    WidgetGroup("store_orange", listOf(
        WidgetShape("store_orange_square", "square", R.drawable.w_store_orange_square, 824, 824, 124, 157, 140, 666, 686),
        WidgetShape("store_orange_pill", "pill", R.drawable.w_store_orange_pill, 996, 399, 199, 373, 67, 620, 332),
        WidgetShape("store_orange_vertical", "vertical", R.drawable.w_store_orange_vertical, 330, 879, 165, 62, 329, 267, 549)
    )),
    WidgetGroup("download_blue", listOf(
        WidgetShape("download_blue_square", "square", R.drawable.w_download_blue_square, 824, 824, 124, 245, 226, 578, 612),
        WidgetShape("download_blue_pill", "pill", R.drawable.w_download_blue_pill, 996, 399, 199, 416, 108, 578, 297),
        WidgetShape("download_blue_vertical", "vertical", R.drawable.w_download_blue_vertical, 330, 879, 165, 97, 363, 232, 520)
    )),
    WidgetGroup("gallery_flower", listOf(
        WidgetShape("gallery_flower_square", "square", R.drawable.w_gallery_flower_square, 824, 824, 124, 120, 123, 701, 699),
        WidgetShape("gallery_flower_pill", "pill", R.drawable.w_gallery_flower_pill, 996, 399, 199, 316, 19, 678, 378),
        WidgetShape("gallery_flower_vertical", "vertical", R.drawable.w_gallery_flower_vertical, 330, 879, 165, 11, 287, 317, 591)
    )),
    WidgetGroup("flower_pink", listOf(
        WidgetShape("flower_pink_square", "square", R.drawable.w_flower_pink_square, 824, 824, 124, 189, 199, 629, 634),
        WidgetShape("flower_pink_pill", "pill", R.drawable.w_flower_pink_pill, 996, 399, 199, 389, 96, 603, 308),
        WidgetShape("flower_pink_vertical", "vertical", R.drawable.w_flower_pink_vertical, 330, 879, 165, 75, 353, 252, 529)
    )),
    WidgetGroup("music_green", listOf(
        WidgetShape("music_green_square", "square", R.drawable.w_music_green_square, 824, 824, 124, 225, 97, 598, 727),
        WidgetShape("music_green_pill", "pill", R.drawable.w_music_green_pill, 996, 399, 199, 407, 47, 587, 352),
        WidgetShape("music_green_vertical", "vertical", R.drawable.w_music_green_vertical, 330, 879, 165, 90, 312, 239, 565)
    )),
    WidgetGroup("music_teal", listOf(
        WidgetShape("music_teal_square", "square", R.drawable.w_music_teal_square, 824, 824, 124, 236, 87, 579, 700),
        WidgetShape("music_teal_pill", "pill", R.drawable.w_music_teal_pill, 996, 399, 199, 413, 41, 578, 339),
        WidgetShape("music_teal_vertical", "vertical", R.drawable.w_music_teal_vertical, 330, 879, 165, 95, 308, 231, 555)
    )),
    WidgetGroup("notes_red", listOf(
        WidgetShape("notes_red_square", "square", R.drawable.w_notes_red_square, 824, 824, 124, 146, 131, 700, 682),
        WidgetShape("notes_red_pill", "pill", R.drawable.w_notes_red_pill, 996, 399, 199, 368, 64, 636, 329),
        WidgetShape("notes_red_vertical", "vertical", R.drawable.w_notes_red_vertical, 330, 879, 165, 58, 327, 279, 546)
    )),
    WidgetGroup("todo_blue_check", listOf(
        WidgetShape("todo_blue_check_square", "square", R.drawable.w_todo_blue_check_square, 824, 824, 124, 219, 253, 613, 570),
        WidgetShape("todo_blue_check_pill", "pill", R.drawable.w_todo_blue_check_pill, 996, 399, 199, 404, 122, 595, 276),
        WidgetShape("todo_blue_check_vertical", "vertical", R.drawable.w_todo_blue_check_vertical, 330, 879, 165, 87, 375, 245, 502)
    )),
    WidgetGroup("todo_blue_check2", listOf(
        WidgetShape("todo_blue_check2_square", "square", R.drawable.w_todo_blue_check2_square, 824, 824, 124, 178, 198, 653, 625),
        WidgetShape("todo_blue_check2_pill", "pill", R.drawable.w_todo_blue_check2_pill, 996, 399, 199, 384, 95, 614, 302),
        WidgetShape("todo_blue_check2_vertical", "vertical", R.drawable.w_todo_blue_check2_vertical, 330, 879, 165, 71, 353, 262, 524)
    )),
    WidgetGroup("lock_green", listOf(
        WidgetShape("lock_green_square", "square", R.drawable.w_lock_green_square, 824, 824, 124, 171, 101, 648, 701),
        WidgetShape("lock_green_pill", "pill", R.drawable.w_lock_green_pill, 996, 399, 199, 382, 49, 612, 340),
        WidgetShape("lock_green_vertical", "vertical", R.drawable.w_lock_green_vertical, 330, 879, 165, 69, 314, 260, 555)
    )),
    WidgetGroup("stats_red", listOf(
        WidgetShape("stats_red_square", "square", R.drawable.w_stats_red_square, 824, 824, 124, 235, 226, 564, 602),
        WidgetShape("stats_red_pill", "pill", R.drawable.w_stats_red_pill, 996, 399, 199, 411, 108, 571, 292),
        WidgetShape("stats_red_vertical", "vertical", R.drawable.w_stats_red_vertical, 330, 879, 165, 93, 363, 227, 516)
    )),
    WidgetGroup("link_orange", listOf(
        WidgetShape("link_orange_square", "square", R.drawable.w_link_orange_square, 824, 824, 124, 145, 162, 661, 678),
        WidgetShape("link_orange_pill", "pill", R.drawable.w_link_orange_pill, 996, 399, 199, 368, 78, 618, 328),
        WidgetShape("link_orange_vertical", "vertical", R.drawable.w_link_orange_vertical, 330, 879, 165, 58, 339, 265, 545)
    )),
    WidgetGroup("clips_purple", listOf(
        WidgetShape("clips_purple_square", "square", R.drawable.w_clips_purple_square, 824, 824, 124, 140, 147, 683, 676),
        WidgetShape("clips_purple_pill", "pill", R.drawable.w_clips_purple_pill, 996, 399, 199, 365, 71, 628, 327),
        WidgetShape("clips_purple_vertical", "vertical", R.drawable.w_clips_purple_vertical, 330, 879, 165, 56, 332, 273, 544)
    )),
    WidgetGroup("ai_gradient_a", listOf(
        WidgetShape("ai_gradient_a_square", "square", R.drawable.w_ai_gradient_a_square, 824, 824, 124, 225, 209, 616, 599),
        WidgetShape("ai_gradient_a_pill", "pill", R.drawable.w_ai_gradient_a_pill, 996, 399, 199, 405, 68, 694, 290),
        WidgetShape("ai_gradient_a_vertical", "vertical", R.drawable.w_ai_gradient_a_vertical, 330, 879, 165, 48, 355, 315, 603)
    )),
    WidgetGroup("ai_purple_sparkle", listOf(
        WidgetShape("ai_purple_sparkle_square", "square", R.drawable.w_ai_purple_sparkle_square, 824, 824, 124, 124, 110, 705, 695),
        WidgetShape("ai_purple_sparkle_pill", "pill", R.drawable.w_ai_purple_sparkle_pill, 996, 399, 199, 359, 53, 638, 335),
        WidgetShape("ai_purple_sparkle_vertical", "vertical", R.drawable.w_ai_purple_sparkle_vertical, 330, 879, 165, 50, 318, 281, 551)
    )),
    WidgetGroup("ai_red_sparkle", listOf(
        WidgetShape("ai_red_sparkle_square", "square", R.drawable.w_ai_red_sparkle_square, 824, 824, 124, 96, 97, 718, 726),
        WidgetShape("ai_red_sparkle_pill", "pill", R.drawable.w_ai_red_sparkle_pill, 996, 399, 199, 344, 47, 646, 351),
        WidgetShape("ai_red_sparkle_vertical", "vertical", R.drawable.w_ai_red_sparkle_vertical, 330, 879, 165, 38, 313, 288, 564)
    )),
    WidgetGroup("themes_rainbow", listOf(
        WidgetShape("themes_rainbow_square", "square", R.drawable.w_themes_rainbow_square, 824, 824, 124, 144, 137, 671, 670),
        WidgetShape("themes_rainbow_pill", "pill", R.drawable.w_themes_rainbow_pill, 996, 399, 199, 366, 66, 623, 325),
        WidgetShape("themes_rainbow_vertical", "vertical", R.drawable.w_themes_rainbow_vertical, 330, 879, 165, 57, 327, 269, 543)
    )),
    WidgetGroup("themes_orange_purple", listOf(
        WidgetShape("themes_orange_purple_square", "square", R.drawable.w_themes_orange_purple_square, 824, 824, 124, 80, 80, 703, 704),
        WidgetShape("themes_orange_purple_pill", "pill", R.drawable.w_themes_orange_purple_pill, 996, 399, 199, 336, 38, 640, 342),
        WidgetShape("themes_orange_purple_vertical", "vertical", R.drawable.w_themes_orange_purple_vertical, 330, 879, 165, 31, 305, 283, 557)
    )),
    WidgetGroup("wallpaper_pink_brush", listOf(
        WidgetShape("wallpaper_pink_brush_square", "square", R.drawable.w_wallpaper_pink_brush_square, 824, 824, 124, 157, 97, 666, 761),
        WidgetShape("wallpaper_pink_brush_pill", "pill", R.drawable.w_wallpaper_pink_brush_pill, 996, 399, 199, 374, 46, 621, 368),
        WidgetShape("wallpaper_pink_brush_vertical", "vertical", R.drawable.w_wallpaper_pink_brush_vertical, 330, 879, 165, 62, 310, 269, 578)
    )),
    WidgetGroup("wand_purple", listOf(
        WidgetShape("wand_purple_square", "square", R.drawable.w_wand_purple_square, 824, 824, 124, 223, 240, 620, 626),
        WidgetShape("wand_purple_pill", "pill", R.drawable.w_wand_purple_pill, 996, 399, 199, 406, 115, 598, 304),
        WidgetShape("wand_purple_vertical", "vertical", R.drawable.w_wand_purple_vertical, 330, 879, 165, 90, 369, 248, 525)
    )),
    WidgetGroup("triangle_green", listOf(
        WidgetShape("triangle_green_square", "square", R.drawable.w_triangle_green_square, 824, 824, 124, 197, 206, 626, 588),
        WidgetShape("triangle_green_pill", "pill", R.drawable.w_triangle_green_pill, 996, 399, 199, 392, 99, 602, 285),
        WidgetShape("triangle_green_vertical", "vertical", R.drawable.w_triangle_green_vertical, 330, 879, 165, 78, 355, 251, 510)
    ))
)

fun findShape(key: String): WidgetShape? {
    for (g in GROUPS) {
        for (s in g.shapes) {
            if (s.key == key) return s
        }
    }
    return null
}

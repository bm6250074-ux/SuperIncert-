package com.incertus.superincert

/**
 * To add a new widget:
 * 1) put its image in app/src/main/res/drawable-nodpi/w_NAME.png
 * 2) add a WidgetDef line below (candidates = package names tried in order,
 *    or "action:android.intent.action.XXX" to open a system action).
 * You can also change the app of any widget on the phone: long-press the widget.
 */
data class WidgetDef(
    val id: String,
    val label: String,
    val iconRes: Int,
    val candidates: List<String>
)

val WIDGETS = listOf(
    WidgetDef("phone", "Phone", R.drawable.w_phone, listOf("com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer", "action:android.intent.action.DIAL")),
    WidgetDef("messages", "Messages", R.drawable.w_messages, listOf("com.google.android.apps.messaging", "com.android.mms", "com.samsung.android.messaging")),
    WidgetDef("camera", "Camera", R.drawable.w_camera, listOf("com.android.camera", "com.android.camera2", "com.google.android.GoogleCamera", "com.sec.android.app.camera")),
    WidgetDef("gallery", "Gallery", R.drawable.w_gallery, listOf("com.miui.gallery", "com.google.android.apps.photos", "com.android.gallery3d", "com.sec.android.gallery3d")),
    WidgetDef("browser", "Browser", R.drawable.w_browser, listOf("com.mi.globalbrowser", "com.android.browser", "com.android.chrome")),
    WidgetDef("google", "Google", R.drawable.w_google, listOf("com.google.android.googlequicksearchbox")),
    WidgetDef("play", "Play Store", R.drawable.w_play, listOf("com.android.vending")),
    WidgetDef("settings", "Settings", R.drawable.w_settings, listOf("com.android.settings")),
    WidgetDef("assistant", "Assistant", R.drawable.w_assistant, listOf("com.google.android.apps.googleassistant", "com.miui.voiceassist", "com.google.android.googlequicksearchbox")),
    WidgetDef("mail", "Mail", R.drawable.w_mail, listOf("com.google.android.gm", "com.android.email", "com.microsoft.office.outlook")),
    WidgetDef("calendar", "Calendar", R.drawable.w_calendar, listOf("com.google.android.calendar", "com.android.calendar", "com.samsung.android.calendar")),
    WidgetDef("clock", "Clock", R.drawable.w_clock, listOf("com.google.android.deskclock", "com.android.deskclock", "com.sec.android.app.clockpackage")),
    WidgetDef("calc", "Calculator", R.drawable.w_calc, listOf("com.google.android.calculator", "com.miui.calculator", "com.android.calculator2", "com.sec.android.app.popupcalculator")),
    WidgetDef("notes", "Notes", R.drawable.w_notes, listOf("com.miui.notes", "com.google.android.keep", "com.samsung.android.app.notes")),
    WidgetDef("quicknote", "Tasks", R.drawable.w_quicknote, listOf("com.google.android.apps.tasks", "com.google.android.keep", "com.miui.notes")),
    WidgetDef("files", "Files", R.drawable.w_files, listOf("com.google.android.apps.nbu.files", "com.mi.android.globalFileexplorer", "com.android.fileexplorer", "com.google.android.documentsui", "com.android.documentsui")),
    WidgetDef("download", "Downloads", R.drawable.w_download, listOf("com.android.providers.downloads.ui", "com.google.android.apps.nbu.files")),
    WidgetDef("music", "Music", R.drawable.w_music, listOf("com.google.android.apps.youtube.music", "com.miui.player", "com.spotify.music")),
    WidgetDef("video", "Video", R.drawable.w_video, listOf("com.miui.videoplayer", "com.miui.video", "com.mxtech.videoplayer.ad", "com.google.android.videos")),
    WidgetDef("vlc", "VLC", R.drawable.w_vlc, listOf("org.videolan.vlc")),
    WidgetDef("recorder", "Recorder", R.drawable.w_recorder, listOf("com.google.android.apps.recorder", "com.android.soundrecorder")),
    WidgetDef("scanner", "Scanner", R.drawable.w_scanner, listOf("com.xiaomi.scanner", "com.google.android.apps.docs")),
    WidgetDef("weather", "Weather", R.drawable.w_weather, listOf("com.miui.weather2", "com.google.android.apps.weather", "com.sec.android.daemonservice")),
    WidgetDef("weather2", "Forecast", R.drawable.w_weather2, listOf("com.miui.weather2", "com.google.android.apps.weather")),
    WidgetDef("battery", "Battery", R.drawable.w_battery, listOf("action:android.intent.action.POWER_USAGE_SUMMARY")),
    WidgetDef("memory", "Memory", R.drawable.w_memory, listOf("com.miui.securitycenter", "com.android.settings")),
    WidgetDef("cleaner", "Cleaner", R.drawable.w_cleaner, listOf("com.miui.cleaner", "com.miui.securitycenter", "com.google.android.apps.nbu.files")),
    WidgetDef("security", "Security", R.drawable.w_security, listOf("com.miui.securitycenter", "com.samsung.android.lool")),
    WidgetDef("transfer", "Transfer", R.drawable.w_transfer, listOf("com.miui.mishare.connectivity", "com.xiaomi.midrop", "com.google.android.gms")),
    WidgetDef("wallet", "Wallet", R.drawable.w_wallet, listOf("com.google.android.apps.walletnfcrel", "com.mipay.wallet", "com.mipay.wallet.in")),
    WidgetDef("store", "Mi Store", R.drawable.w_store, listOf("com.xiaomi.shop", "com.mi.global.shop")),
    WidgetDef("telegram", "Telegram", R.drawable.w_telegram, listOf("org.telegram.messenger", "org.telegram.messenger.web", "org.thunderdog.challegram")),
    WidgetDef("box", "Backup", R.drawable.w_box, listOf("com.miui.backup", "com.google.android.apps.docs")),
    WidgetDef("ring", "Find", R.drawable.w_ring, listOf("com.google.android.apps.adm")),
    WidgetDef("help", "Help", R.drawable.w_help, listOf("com.miui.bugreport", "com.google.android.apps.helprtc")),
)

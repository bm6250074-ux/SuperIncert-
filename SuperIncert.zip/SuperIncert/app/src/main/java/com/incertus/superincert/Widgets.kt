package com.incertus.superincert

/** One home-screen widget shape. key = group + "_" + shape. */
data class WidgetShape(val key: String, val shape: String, val iconRes: Int)

/** One tile in the app: all shapes of the same icon. */
data class WidgetGroup(val id: String, val shapes: List<WidgetShape>)

val GROUPS = listOf(
    WidgetGroup("phone_green_square", listOf(
        WidgetShape("phone_green_square_square", "square", R.drawable.w_phone_green_square_square),
        WidgetShape("phone_green_square_pill", "pill", R.drawable.w_phone_green_square_pill),
        WidgetShape("phone_green_square_vertical", "vertical", R.drawable.w_phone_green_square_vertical)
    )),
    WidgetGroup("phone_green_circle", listOf(
        WidgetShape("phone_green_circle_square", "square", R.drawable.w_phone_green_circle_square),
        WidgetShape("phone_green_circle_pill", "pill", R.drawable.w_phone_green_circle_pill),
        WidgetShape("phone_green_circle_vertical", "vertical", R.drawable.w_phone_green_circle_vertical)
    )),
    WidgetGroup("phone_green_circle2", listOf(
        WidgetShape("phone_green_circle2_square", "square", R.drawable.w_phone_green_circle2_square),
        WidgetShape("phone_green_circle2_pill", "pill", R.drawable.w_phone_green_circle2_pill),
        WidgetShape("phone_green_circle2_vertical", "vertical", R.drawable.w_phone_green_circle2_vertical)
    )),
    WidgetGroup("messages_green", listOf(
        WidgetShape("messages_green_square", "square", R.drawable.w_messages_green_square),
        WidgetShape("messages_green_pill", "pill", R.drawable.w_messages_green_pill),
        WidgetShape("messages_green_vertical", "vertical", R.drawable.w_messages_green_vertical)
    )),
    WidgetGroup("contacts_gray_a", listOf(
        WidgetShape("contacts_gray_a_square", "square", R.drawable.w_contacts_gray_a_square),
        WidgetShape("contacts_gray_a_pill", "pill", R.drawable.w_contacts_gray_a_pill),
        WidgetShape("contacts_gray_a_vertical", "vertical", R.drawable.w_contacts_gray_a_vertical)
    )),
    WidgetGroup("home_blue", listOf(
        WidgetShape("home_blue_square", "square", R.drawable.w_home_blue_square),
        WidgetShape("home_blue_pill", "pill", R.drawable.w_home_blue_pill),
        WidgetShape("home_blue_vertical", "vertical", R.drawable.w_home_blue_vertical)
    )),
    WidgetGroup("apps_blue", listOf(
        WidgetShape("apps_blue_square", "square", R.drawable.w_apps_blue_square),
        WidgetShape("apps_blue_pill", "pill", R.drawable.w_apps_blue_pill),
        WidgetShape("apps_blue_vertical", "vertical", R.drawable.w_apps_blue_vertical)
    )),
    WidgetGroup("apps_orange_circle", listOf(
        WidgetShape("apps_orange_circle_square", "square", R.drawable.w_apps_orange_circle_square),
        WidgetShape("apps_orange_circle_pill", "pill", R.drawable.w_apps_orange_circle_pill),
        WidgetShape("apps_orange_circle_vertical", "vertical", R.drawable.w_apps_orange_circle_vertical)
    )),
    WidgetGroup("store_orange", listOf(
        WidgetShape("store_orange_square", "square", R.drawable.w_store_orange_square),
        WidgetShape("store_orange_pill", "pill", R.drawable.w_store_orange_pill),
        WidgetShape("store_orange_vertical", "vertical", R.drawable.w_store_orange_vertical)
    )),
    WidgetGroup("download_blue", listOf(
        WidgetShape("download_blue_square", "square", R.drawable.w_download_blue_square),
        WidgetShape("download_blue_pill", "pill", R.drawable.w_download_blue_pill),
        WidgetShape("download_blue_vertical", "vertical", R.drawable.w_download_blue_vertical)
    )),
    WidgetGroup("gallery_flower", listOf(
        WidgetShape("gallery_flower_square", "square", R.drawable.w_gallery_flower_square),
        WidgetShape("gallery_flower_pill", "pill", R.drawable.w_gallery_flower_pill),
        WidgetShape("gallery_flower_vertical", "vertical", R.drawable.w_gallery_flower_vertical)
    )),
    WidgetGroup("flower_pink", listOf(
        WidgetShape("flower_pink_square", "square", R.drawable.w_flower_pink_square),
        WidgetShape("flower_pink_pill", "pill", R.drawable.w_flower_pink_pill),
        WidgetShape("flower_pink_vertical", "vertical", R.drawable.w_flower_pink_vertical)
    )),
    WidgetGroup("music_green", listOf(
        WidgetShape("music_green_square", "square", R.drawable.w_music_green_square),
        WidgetShape("music_green_pill", "pill", R.drawable.w_music_green_pill),
        WidgetShape("music_green_vertical", "vertical", R.drawable.w_music_green_vertical)
    )),
    WidgetGroup("music_teal", listOf(
        WidgetShape("music_teal_square", "square", R.drawable.w_music_teal_square),
        WidgetShape("music_teal_pill", "pill", R.drawable.w_music_teal_pill),
        WidgetShape("music_teal_vertical", "vertical", R.drawable.w_music_teal_vertical)
    )),
    WidgetGroup("notes_red", listOf(
        WidgetShape("notes_red_square", "square", R.drawable.w_notes_red_square),
        WidgetShape("notes_red_pill", "pill", R.drawable.w_notes_red_pill),
        WidgetShape("notes_red_vertical", "vertical", R.drawable.w_notes_red_vertical)
    )),
    WidgetGroup("todo_blue_check", listOf(
        WidgetShape("todo_blue_check_square", "square", R.drawable.w_todo_blue_check_square),
        WidgetShape("todo_blue_check_pill", "pill", R.drawable.w_todo_blue_check_pill),
        WidgetShape("todo_blue_check_vertical", "vertical", R.drawable.w_todo_blue_check_vertical)
    )),
    WidgetGroup("todo_blue_check2", listOf(
        WidgetShape("todo_blue_check2_square", "square", R.drawable.w_todo_blue_check2_square),
        WidgetShape("todo_blue_check2_pill", "pill", R.drawable.w_todo_blue_check2_pill),
        WidgetShape("todo_blue_check2_vertical", "vertical", R.drawable.w_todo_blue_check2_vertical)
    )),
    WidgetGroup("lock_green", listOf(
        WidgetShape("lock_green_square", "square", R.drawable.w_lock_green_square),
        WidgetShape("lock_green_pill", "pill", R.drawable.w_lock_green_pill),
        WidgetShape("lock_green_vertical", "vertical", R.drawable.w_lock_green_vertical)
    )),
    WidgetGroup("stats_red", listOf(
        WidgetShape("stats_red_square", "square", R.drawable.w_stats_red_square),
        WidgetShape("stats_red_pill", "pill", R.drawable.w_stats_red_pill),
        WidgetShape("stats_red_vertical", "vertical", R.drawable.w_stats_red_vertical)
    )),
    WidgetGroup("link_orange", listOf(
        WidgetShape("link_orange_square", "square", R.drawable.w_link_orange_square),
        WidgetShape("link_orange_pill", "pill", R.drawable.w_link_orange_pill),
        WidgetShape("link_orange_vertical", "vertical", R.drawable.w_link_orange_vertical)
    )),
    WidgetGroup("clips_purple", listOf(
        WidgetShape("clips_purple_square", "square", R.drawable.w_clips_purple_square),
        WidgetShape("clips_purple_pill", "pill", R.drawable.w_clips_purple_pill),
        WidgetShape("clips_purple_vertical", "vertical", R.drawable.w_clips_purple_vertical)
    )),
    WidgetGroup("ai_gradient_a", listOf(
        WidgetShape("ai_gradient_a_square", "square", R.drawable.w_ai_gradient_a_square),
        WidgetShape("ai_gradient_a_pill", "pill", R.drawable.w_ai_gradient_a_pill),
        WidgetShape("ai_gradient_a_vertical", "vertical", R.drawable.w_ai_gradient_a_vertical)
    )),
    WidgetGroup("ai_purple_sparkle", listOf(
        WidgetShape("ai_purple_sparkle_square", "square", R.drawable.w_ai_purple_sparkle_square),
        WidgetShape("ai_purple_sparkle_pill", "pill", R.drawable.w_ai_purple_sparkle_pill),
        WidgetShape("ai_purple_sparkle_vertical", "vertical", R.drawable.w_ai_purple_sparkle_vertical)
    )),
    WidgetGroup("ai_red_sparkle", listOf(
        WidgetShape("ai_red_sparkle_square", "square", R.drawable.w_ai_red_sparkle_square),
        WidgetShape("ai_red_sparkle_pill", "pill", R.drawable.w_ai_red_sparkle_pill),
        WidgetShape("ai_red_sparkle_vertical", "vertical", R.drawable.w_ai_red_sparkle_vertical)
    )),
    WidgetGroup("themes_rainbow", listOf(
        WidgetShape("themes_rainbow_square", "square", R.drawable.w_themes_rainbow_square),
        WidgetShape("themes_rainbow_pill", "pill", R.drawable.w_themes_rainbow_pill),
        WidgetShape("themes_rainbow_vertical", "vertical", R.drawable.w_themes_rainbow_vertical)
    )),
    WidgetGroup("themes_orange_purple", listOf(
        WidgetShape("themes_orange_purple_square", "square", R.drawable.w_themes_orange_purple_square),
        WidgetShape("themes_orange_purple_pill", "pill", R.drawable.w_themes_orange_purple_pill),
        WidgetShape("themes_orange_purple_vertical", "vertical", R.drawable.w_themes_orange_purple_vertical)
    )),
    WidgetGroup("wallpaper_pink_brush", listOf(
        WidgetShape("wallpaper_pink_brush_square", "square", R.drawable.w_wallpaper_pink_brush_square),
        WidgetShape("wallpaper_pink_brush_pill", "pill", R.drawable.w_wallpaper_pink_brush_pill),
        WidgetShape("wallpaper_pink_brush_vertical", "vertical", R.drawable.w_wallpaper_pink_brush_vertical)
    )),
    WidgetGroup("wand_purple", listOf(
        WidgetShape("wand_purple_square", "square", R.drawable.w_wand_purple_square),
        WidgetShape("wand_purple_pill", "pill", R.drawable.w_wand_purple_pill),
        WidgetShape("wand_purple_vertical", "vertical", R.drawable.w_wand_purple_vertical)
    )),
    WidgetGroup("triangle_green", listOf(
        WidgetShape("triangle_green_square", "square", R.drawable.w_triangle_green_square),
        WidgetShape("triangle_green_pill", "pill", R.drawable.w_triangle_green_pill),
        WidgetShape("triangle_green_vertical", "vertical", R.drawable.w_triangle_green_vertical)
    ))
)

fun findShape(key: String): WidgetShape? {
    for (g in GROUPS) {
        for (s in g.shapes) {
            if (s.key == key) return s
        }
    }
    return null
}

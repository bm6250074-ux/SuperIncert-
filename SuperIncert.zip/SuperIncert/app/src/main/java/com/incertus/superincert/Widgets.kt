package com.incertus.superincert

/** One home-screen widget shape. key = group + "_" + shape. */
data class WidgetShape(
    val key: String,
    val shape: String,
    val iconRes: Int,
    val w: Int,      // source image size
    val h: Int,
    val cap: Int,    // corner/cap size that must never be stretched
    val gx0: Int,    // glyph box (never stretched)
    val gy0: Int,
    val gx1: Int,
    val gy1: Int
)

/** One tile in the app: all shapes of the same icon. */
data class WidgetGroup(val id: String, val shapes: List<WidgetShape>)

val GROUPS = listOf(
    WidgetGroup("com_android_providers_contacts_calllogprovider", listOf(
        WidgetShape("com_android_providers_contacts_calllogprovider_square", "square", R.drawable.w_com_android_providers_contacts_calllogprovider_square, 824, 824, 109, 116, 106, 717, 707),
        WidgetShape("com_android_providers_contacts_calllogprovider_pill", "pill", R.drawable.w_com_android_providers_contacts_calllogprovider_pill, 996, 399, 95, 353, 51, 646, 343),
        WidgetShape("com_android_providers_contacts_calllogprovider_vertical", "vertical", R.drawable.w_com_android_providers_contacts_calllogprovider_vertical, 330, 879, 78, 45, 315, 287, 558)
    )),
    WidgetGroup("com_android_mms", listOf(
        WidgetShape("com_android_mms_square", "square", R.drawable.w_com_android_mms_square, 824, 824, 109, 79, 100, 744, 719),
        WidgetShape("com_android_mms_pill", "pill", R.drawable.w_com_android_mms_pill, 996, 399, 95, 335, 48, 658, 348),
        WidgetShape("com_android_mms_vertical", "vertical", R.drawable.w_com_android_mms_vertical, 330, 879, 78, 30, 313, 298, 561)
    )),
    WidgetGroup("com_android_contacts", listOf(
        WidgetShape("com_android_contacts_square", "square", R.drawable.w_com_android_contacts_square, 824, 824, 109, 82, 82, 737, 737),
        WidgetShape("com_android_contacts_pill", "pill", R.drawable.w_com_android_contacts_pill, 996, 399, 95, 337, 39, 656, 358),
        WidgetShape("com_android_contacts_vertical", "vertical", R.drawable.w_com_android_contacts_vertical, 330, 879, 78, 32, 306, 296, 570)
    )),
    WidgetGroup("com_android_browser", listOf(
        WidgetShape("com_android_browser_square", "square", R.drawable.w_com_android_browser_square, 824, 824, 109, 63, 104, 761, 714),
        WidgetShape("com_android_browser_pill", "pill", R.drawable.w_com_android_browser_pill, 996, 399, 95, 329, 49, 666, 346),
        WidgetShape("com_android_browser_vertical", "vertical", R.drawable.w_com_android_browser_vertical, 330, 879, 78, 25, 314, 304, 561)
    )),
    WidgetGroup("com_android_camera", listOf(
        WidgetShape("com_android_camera_square", "square", R.drawable.w_com_android_camera_square, 824, 824, 109, 75, 132, 744, 677),
        WidgetShape("com_android_camera_pill", "pill", R.drawable.w_com_android_camera_pill, 996, 399, 95, 333, 63, 659, 328),
        WidgetShape("com_android_camera_vertical", "vertical", R.drawable.w_com_android_camera_vertical, 330, 879, 78, 29, 325, 299, 546)
    )),
    WidgetGroup("com_android_gallery3d", listOf(
        WidgetShape("com_android_gallery3d_square", "square", R.drawable.w_com_android_gallery3d_square, 824, 824, 109, 41, 58, 764, 775),
        WidgetShape("com_android_gallery3d_pill", "pill", R.drawable.w_com_android_gallery3d_pill, 996, 399, 95, 317, 27, 668, 376),
        WidgetShape("com_android_gallery3d_vertical", "vertical", R.drawable.w_com_android_gallery3d_vertical, 330, 879, 78, 15, 296, 307, 585)
    )),
    WidgetGroup("com_android_music", listOf(
        WidgetShape("com_android_music_square", "square", R.drawable.w_com_android_music_square, 824, 824, 109, 70, 72, 754, 757),
        WidgetShape("com_android_music_pill", "pill", R.drawable.w_com_android_music_pill, 996, 399, 95, 331, 34, 664, 367),
        WidgetShape("com_android_music_vertical", "vertical", R.drawable.w_com_android_music_vertical, 330, 879, 78, 27, 302, 303, 578)
    )),
    WidgetGroup("com_android_soundrecorder", listOf(
        WidgetShape("com_android_soundrecorder_square", "square", R.drawable.w_com_android_soundrecorder_square, 824, 824, 109, 15, 43, 808, 780),
        WidgetShape("com_android_soundrecorder_pill", "pill", R.drawable.w_com_android_soundrecorder_pill, 996, 399, 95, 297, 20, 696, 378),
        WidgetShape("com_android_soundrecorder_vertical", "vertical", R.drawable.w_com_android_soundrecorder_vertical, 330, 879, 78, 11, 290, 317, 587)
    )),
    WidgetGroup("com_miui_screenrecorder", listOf(
        WidgetShape("com_miui_screenrecorder_square", "square", R.drawable.w_com_miui_screenrecorder_square, 824, 824, 109, 124, 230, 688, 589),
        WidgetShape("com_miui_screenrecorder_pill", "pill", R.drawable.w_com_miui_screenrecorder_pill, 996, 399, 95, 357, 111, 631, 286),
        WidgetShape("com_miui_screenrecorder_vertical", "vertical", R.drawable.w_com_miui_screenrecorder_vertical, 330, 879, 78, 48, 365, 276, 511)
    )),
    WidgetGroup("com_android_calendar", listOf(
        WidgetShape("com_android_calendar_square", "square", R.drawable.w_com_android_calendar_square, 824, 824, 109, 15, 188, 808, 500),
        WidgetShape("com_android_calendar_pill", "pill", R.drawable.w_com_android_calendar_pill, 996, 399, 95, 285, 35, 709, 348),
        WidgetShape("com_android_calendar_vertical", "vertical", R.drawable.w_com_android_calendar_vertical, 330, 879, 78, 11, 261, 318, 563)
    )),
    WidgetGroup("com_android_deskclock", listOf(
        WidgetShape("com_android_deskclock_square", "square", R.drawable.w_com_android_deskclock_square, 824, 824, 109, 35, 34, 785, 784),
        WidgetShape("com_android_deskclock_pill", "pill", R.drawable.w_com_android_deskclock_pill, 996, 399, 95, 314, 16, 679, 380),
        WidgetShape("com_android_deskclock_vertical", "vertical", R.drawable.w_com_android_deskclock_vertical, 330, 879, 78, 13, 287, 315, 589)
    )),
    WidgetGroup("com_android_calculator2", listOf(
        WidgetShape("com_android_calculator2_square", "square", R.drawable.w_com_android_calculator2_square, 824, 824, 109, 131, 131, 737, 738),
        WidgetShape("com_android_calculator2_pill", "pill", R.drawable.w_com_android_calculator2_pill, 996, 399, 95, 109, 105, 914, 293),
        WidgetShape("com_android_calculator2_vertical", "vertical", R.drawable.w_com_android_calculator2_vertical, 330, 879, 78, 94, 166, 235, 730)
    )),
    WidgetGroup("com_miui_notes", listOf(
        WidgetShape("com_miui_notes_square", "square", R.drawable.w_com_miui_notes_square, 824, 824, 109, 101, 15, 808, 665),
        WidgetShape("com_miui_notes_pill", "pill", R.drawable.w_com_miui_notes_pill, 996, 399, 95, 348, 11, 700, 322),
        WidgetShape("com_miui_notes_vertical", "vertical", R.drawable.w_com_miui_notes_vertical, 330, 879, 78, 43, 269, 318, 541)
    )),
    WidgetGroup("com_android_fileexplorer", listOf(
        WidgetShape("com_android_fileexplorer_square", "square", R.drawable.w_com_android_fileexplorer_square, 824, 824, 109, 64, 124, 755, 688),
        WidgetShape("com_android_fileexplorer_pill", "pill", R.drawable.w_com_android_fileexplorer_pill, 996, 399, 95, 328, 59, 664, 334),
        WidgetShape("com_android_fileexplorer_vertical", "vertical", R.drawable.w_com_android_fileexplorer_vertical, 330, 879, 78, 24, 322, 303, 550)
    )),
    WidgetGroup("com_android_providers_downloads", listOf(
        WidgetShape("com_android_providers_downloads_square", "square", R.drawable.w_com_android_providers_downloads_square, 824, 824, 109, 159, 121, 661, 699),
        WidgetShape("com_android_providers_downloads_pill", "pill", R.drawable.w_com_android_providers_downloads_pill, 996, 399, 95, 374, 58, 618, 339),
        WidgetShape("com_android_providers_downloads_vertical", "vertical", R.drawable.w_com_android_providers_downloads_vertical, 330, 879, 78, 62, 321, 265, 554)
    )),
    WidgetGroup("com_android_settings", listOf(
        WidgetShape("com_android_settings_square", "square", R.drawable.w_com_android_settings_square, 824, 824, 109, 35, 34, 785, 783),
        WidgetShape("com_android_settings_pill", "pill", R.drawable.w_com_android_settings_pill, 996, 399, 95, 314, 15, 679, 379),
        WidgetShape("com_android_settings_vertical", "vertical", R.drawable.w_com_android_settings_vertical, 330, 879, 78, 13, 287, 315, 588)
    )),
    WidgetGroup("com_miui_securitycenter_main", listOf(
        WidgetShape("com_miui_securitycenter_main_square", "square", R.drawable.w_com_miui_securitycenter_main_square, 824, 824, 109, 114, 79, 705, 741),
        WidgetShape("com_miui_securitycenter_main_pill", "pill", R.drawable.w_com_miui_securitycenter_main_pill, 996, 399, 95, 352, 37, 640, 359),
        WidgetShape("com_miui_securitycenter_main_vertical", "vertical", R.drawable.w_com_miui_securitycenter_main_vertical, 330, 879, 78, 44, 304, 283, 571)
    )),
    WidgetGroup("com_miui_weather2", listOf(
        WidgetShape("com_miui_weather2_square", "square", R.drawable.w_com_miui_weather2_square, 824, 824, 109, 93, 145, 727, 671),
        WidgetShape("com_miui_weather2_pill", "pill", R.drawable.w_com_miui_weather2_pill, 996, 399, 95, 342, 69, 651, 325),
        WidgetShape("com_miui_weather2_vertical", "vertical", R.drawable.w_com_miui_weather2_vertical, 330, 879, 78, 36, 331, 292, 543)
    )),
    WidgetGroup("com_miui_compass", listOf(
        WidgetShape("com_miui_compass_square", "square", R.drawable.w_com_miui_compass_square, 824, 824, 109, 46, 34, 777, 777),
        WidgetShape("com_miui_compass_pill", "pill", R.drawable.w_com_miui_compass_pill, 996, 399, 95, 320, 16, 674, 376),
        WidgetShape("com_miui_compass_vertical", "vertical", R.drawable.w_com_miui_compass_vertical, 330, 879, 78, 18, 287, 311, 585)
    )),
    WidgetGroup("com_xiaomi_scanner", listOf(
        WidgetShape("com_xiaomi_scanner_square", "square", R.drawable.w_com_xiaomi_scanner_square, 824, 824, 109, 103, 118, 721, 705),
        WidgetShape("com_xiaomi_scanner_pill", "pill", R.drawable.w_com_xiaomi_scanner_pill, 996, 399, 95, 347, 56, 647, 342),
        WidgetShape("com_xiaomi_scanner_vertical", "vertical", R.drawable.w_com_xiaomi_scanner_vertical, 330, 879, 78, 41, 320, 289, 557)
    )),
    WidgetGroup("com_xiaomi_market", listOf(
        WidgetShape("com_xiaomi_market_square", "square", R.drawable.w_com_xiaomi_market_square, 824, 824, 109, 188, 88, 635, 645),
        WidgetShape("com_xiaomi_market_pill", "pill", R.drawable.w_com_xiaomi_market_pill, 996, 399, 95, 388, 41, 606, 313),
        WidgetShape("com_xiaomi_market_vertical", "vertical", R.drawable.w_com_xiaomi_market_vertical, 330, 879, 78, 74, 308, 255, 533)
    )),
    WidgetGroup("com_xiaomi_padshop", listOf(
        WidgetShape("com_xiaomi_padshop_square", "square", R.drawable.w_com_xiaomi_padshop_square, 824, 824, 109, 142, 233, 681, 597),
        WidgetShape("com_xiaomi_padshop_pill", "pill", R.drawable.w_com_xiaomi_padshop_pill, 996, 399, 95, 366, 111, 628, 289),
        WidgetShape("com_xiaomi_padshop_vertical", "vertical", R.drawable.w_com_xiaomi_padshop_vertical, 330, 879, 78, 55, 366, 274, 514)
    )),
    WidgetGroup("com_android_thememanager", listOf(
        WidgetShape("com_android_thememanager_square", "square", R.drawable.w_com_android_thememanager_square, 824, 824, 109, 158, 99, 662, 755),
        WidgetShape("com_android_thememanager_pill", "pill", R.drawable.w_com_android_thememanager_pill, 996, 399, 95, 374, 47, 619, 366),
        WidgetShape("com_android_thememanager_vertical", "vertical", R.drawable.w_com_android_thememanager_vertical, 330, 879, 78, 62, 312, 266, 577)
    )),
    WidgetGroup("com_android_voicedialer", listOf(
        WidgetShape("com_android_voicedialer_square", "square", R.drawable.w_com_android_voicedialer_square, 824, 824, 109, 94, 94, 728, 729),
        WidgetShape("com_android_voicedialer_pill", "pill", R.drawable.w_com_android_voicedialer_pill, 996, 399, 95, 343, 44, 651, 354),
        WidgetShape("com_android_voicedialer_vertical", "vertical", R.drawable.w_com_android_voicedialer_vertical, 330, 879, 78, 37, 310, 292, 567)
    )),
    WidgetGroup("com_milink_service", listOf(
        WidgetShape("com_milink_service_square", "square", R.drawable.w_com_milink_service_square, 824, 824, 109, 118, 153, 705, 663),
        WidgetShape("com_milink_service_pill", "pill", R.drawable.w_com_milink_service_pill, 996, 399, 95, 354, 73, 640, 322),
        WidgetShape("com_milink_service_vertical", "vertical", R.drawable.w_com_milink_service_vertical, 330, 879, 78, 46, 334, 283, 540)
    )),
    WidgetGroup("com_xiaomi_mico", listOf(
        WidgetShape("com_xiaomi_mico_square", "square", R.drawable.w_com_xiaomi_mico_square, 824, 824, 109, 66, 188, 764, 633),
        WidgetShape("com_xiaomi_mico_pill", "pill", R.drawable.w_com_xiaomi_mico_pill, 996, 399, 95, 329, 90, 668, 307),
        WidgetShape("com_xiaomi_mico_vertical", "vertical", R.drawable.w_com_xiaomi_mico_vertical, 330, 879, 78, 25, 348, 307, 528)
    )),
    WidgetGroup("com_xiaomi_smarthome", listOf(
        WidgetShape("com_xiaomi_smarthome_square", "square", R.drawable.w_com_xiaomi_smarthome_square, 824, 824, 109, 178, 178, 645, 706),
        WidgetShape("com_xiaomi_smarthome_pill", "pill", R.drawable.w_com_xiaomi_smarthome_pill, 996, 399, 95, 383, 85, 611, 342),
        WidgetShape("com_xiaomi_smarthome_vertical", "vertical", R.drawable.w_com_xiaomi_smarthome_vertical, 330, 879, 78, 70, 344, 259, 558)
    )),
    WidgetGroup("com_mi_health", listOf(
        WidgetShape("com_mi_health_square", "square", R.drawable.w_com_mi_health_square, 824, 824, 109, 108, 108, 715, 715),
        WidgetShape("com_mi_health_pill", "pill", R.drawable.w_com_mi_health_pill, 996, 399, 95, 349, 51, 645, 347),
        WidgetShape("com_mi_health_vertical", "vertical", R.drawable.w_com_mi_health_vertical, 330, 879, 78, 42, 316, 287, 561)
    )),
    WidgetGroup("com_xiaomi_hm_health", listOf(
        WidgetShape("com_xiaomi_hm_health_square", "square", R.drawable.w_com_xiaomi_hm_health_square, 824, 824, 109, 108, 108, 716, 715),
        WidgetShape("com_xiaomi_hm_health_pill", "pill", R.drawable.w_com_xiaomi_hm_health_pill, 996, 399, 95, 349, 51, 645, 347),
        WidgetShape("com_xiaomi_hm_health_vertical", "vertical", R.drawable.w_com_xiaomi_hm_health_vertical, 330, 879, 78, 42, 316, 287, 561)
    )),
    WidgetGroup("com_xiaomi_gamecenter_pad", listOf(
        WidgetShape("com_xiaomi_gamecenter_pad_square", "square", R.drawable.w_com_xiaomi_gamecenter_pad_square, 824, 824, 109, 70, 133, 752, 693),
        WidgetShape("com_xiaomi_gamecenter_pad_pill", "pill", R.drawable.w_com_xiaomi_gamecenter_pad_pill, 996, 399, 95, 331, 63, 663, 336),
        WidgetShape("com_xiaomi_gamecenter_pad_vertical", "vertical", R.drawable.w_com_xiaomi_gamecenter_pad_vertical, 330, 879, 78, 27, 326, 302, 552)
    )),
    WidgetGroup("com_duokan_reader", listOf(
        WidgetShape("com_duokan_reader_square", "square", R.drawable.w_com_duokan_reader_square, 824, 824, 109, 72, 140, 751, 666),
        WidgetShape("com_duokan_reader_pill", "pill", R.drawable.w_com_duokan_reader_pill, 996, 399, 95, 332, 66, 662, 323),
        WidgetShape("com_duokan_reader_vertical", "vertical", R.drawable.w_com_duokan_reader_vertical, 330, 879, 78, 27, 328, 302, 541)
    )),
    WidgetGroup("com_duokan_phone_remotecontroller", listOf(
        WidgetShape("com_duokan_phone_remotecontroller_square", "square", R.drawable.w_com_duokan_phone_remotecontroller_square, 824, 824, 109, 99, 52, 723, 722),
        WidgetShape("com_duokan_phone_remotecontroller_pill", "pill", R.drawable.w_com_duokan_phone_remotecontroller_pill, 996, 399, 95, 345, 24, 648, 349),
        WidgetShape("com_duokan_phone_remotecontroller_vertical", "vertical", R.drawable.w_com_duokan_phone_remotecontroller_vertical, 330, 879, 78, 39, 294, 289, 563)
    )),
    WidgetGroup("com_miui_fm", listOf(
        WidgetShape("com_miui_fm_square", "square", R.drawable.w_com_miui_fm_square, 824, 824, 109, 103, 119, 720, 737),
        WidgetShape("com_miui_fm_pill", "pill", R.drawable.w_com_miui_fm_pill, 996, 399, 95, 347, 57, 647, 357),
        WidgetShape("com_miui_fm_vertical", "vertical", R.drawable.w_com_miui_fm_vertical, 330, 879, 78, 40, 321, 289, 570)
    ))
)

fun findShape(key: String): WidgetShape? {
    for (g in GROUPS) {
        for (s in g.shapes) {
            if (s.key == key) return s
        }
    }
    return null
}

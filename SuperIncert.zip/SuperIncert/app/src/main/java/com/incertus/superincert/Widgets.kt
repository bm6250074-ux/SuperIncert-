package com.incertus.superincert

/**
 * To add a widget: put the image in res/drawable-nodpi/w_NAME.png,
 * add WidgetDef("NAME", R.drawable.w_NAME) below, create class W_NAME in Providers.kt,
 * and add its <receiver> in AndroidManifest.xml + res/xml/wi_NAME.xml (copy an existing one).
 */
data class WidgetDef(val id: String, val iconRes: Int)

val WIDGETS = listOf(
    WidgetDef("phone", R.drawable.w_phone),
    WidgetDef("messages", R.drawable.w_messages),
    WidgetDef("camera", R.drawable.w_camera),
    WidgetDef("gallery", R.drawable.w_gallery),
    WidgetDef("browser", R.drawable.w_browser),
    WidgetDef("google", R.drawable.w_google),
    WidgetDef("play", R.drawable.w_play),
    WidgetDef("settings", R.drawable.w_settings),
    WidgetDef("assistant", R.drawable.w_assistant),
    WidgetDef("mail", R.drawable.w_mail),
    WidgetDef("calendar", R.drawable.w_calendar),
    WidgetDef("clock", R.drawable.w_clock),
    WidgetDef("calc", R.drawable.w_calc),
    WidgetDef("notes", R.drawable.w_notes),
    WidgetDef("quicknote", R.drawable.w_quicknote),
    WidgetDef("files", R.drawable.w_files),
    WidgetDef("download", R.drawable.w_download),
    WidgetDef("music", R.drawable.w_music),
    WidgetDef("video", R.drawable.w_video),
    WidgetDef("vlc", R.drawable.w_vlc),
    WidgetDef("recorder", R.drawable.w_recorder),
    WidgetDef("scanner", R.drawable.w_scanner),
    WidgetDef("weather", R.drawable.w_weather),
    WidgetDef("weather2", R.drawable.w_weather2),
    WidgetDef("battery", R.drawable.w_battery),
    WidgetDef("memory", R.drawable.w_memory),
    WidgetDef("cleaner", R.drawable.w_cleaner),
    WidgetDef("security", R.drawable.w_security),
    WidgetDef("transfer", R.drawable.w_transfer),
    WidgetDef("wallet", R.drawable.w_wallet),
    WidgetDef("store", R.drawable.w_store),
    WidgetDef("telegram", R.drawable.w_telegram),
    WidgetDef("box", R.drawable.w_box),
    WidgetDef("ring", R.drawable.w_ring),
    WidgetDef("help", R.drawable.w_help),
)

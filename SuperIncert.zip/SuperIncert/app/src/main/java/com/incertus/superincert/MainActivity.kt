package com.incertus.superincert

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ResolveInfo
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.text.TextUtils
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.BaseAdapter
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("superincert", Context.MODE_PRIVATE)
        window.statusBarColor = 0xFF0B1030.toInt()
        window.navigationBarColor = 0xFF0A0E2A.toInt()
        setContentView(buildUi())
    }

    private fun buildUi(): View {
        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(16), dp(26), dp(16), dp(28))
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        // ---- Header ----
        val title = TextView(this)
        title.text = "SuperIncert"
        title.textSize = 38f
        title.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        title.setTextColor(Color.WHITE)
        title.post {
            val wd = title.width.toFloat()
            if (wd > 0f) {
                title.paint.shader = LinearGradient(
                    0f, 0f, wd, 0f,
                    intArrayOf(0xFF8AB4FF.toInt(), 0xFFC58BFF.toInt(), 0xFFFF8AD8.toInt()),
                    null, Shader.TileMode.CLAMP
                )
                title.invalidate()
            }
        }
        col.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val chip = TextView(this)
        chip.text = "by Incertus"
        chip.textSize = 13f
        chip.letterSpacing = 0.08f
        chip.setTextColor(0xFFDCE3FF.toInt())
        chip.setPadding(dp(14), dp(5), dp(14), dp(5))
        val chipBg = GradientDrawable()
        chipBg.cornerRadius = dp(20).toFloat()
        chipBg.setColor(0x26FFFFFF)
        chipBg.setStroke(dp(1), 0x40FFFFFF)
        chip.background = chipBg
        val chipLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        chipLp.topMargin = dp(6)
        col.addView(chip, chipLp)

        val info = TextView(this)
        info.text = "" + WIDGETS.size + " widgets  \u2022  Tap to open  \u2022  Long-press to change app"
        info.textSize = 12f
        info.setTextColor(0x99FFFFFF.toInt())
        info.gravity = Gravity.CENTER
        val infoLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        infoLp.topMargin = dp(14)
        infoLp.bottomMargin = dp(18)
        col.addView(info, infoLp)

        // ---- Grid (3 equal square tiles per row) ----
        val screenW = resources.displayMetrics.widthPixels
        val slot = (screenW - dp(32)) / 3
        val size = slot - dp(12)
        var i = 0
        while (i < WIDGETS.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 3) {
                val idx = i + k
                val cell: View = if (idx < WIDGETS.size) makeTile(WIDGETS[idx], size, idx) else View(this)
                row.addView(cell, LinearLayout.LayoutParams(slot, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            col.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            i += 3
        }

        // ---- Footer ----
        val footer = TextView(this)
        footer.text = "Made with \u2665 by Incertus"
        footer.textSize = 12f
        footer.setTextColor(0x80FFFFFF.toInt())
        footer.gravity = Gravity.CENTER
        val fLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        fLp.topMargin = dp(10)
        col.addView(footer, fLp)

        return scroll
    }

    private fun makeTile(w: WidgetDef, size: Int, index: Int): View {
        val tile = LinearLayout(this)
        tile.orientation = LinearLayout.VERTICAL
        tile.gravity = Gravity.CENTER_HORIZONTAL
        tile.setPadding(dp(6), 0, dp(6), dp(14))

        val box = FrameLayout(this)
        val bg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0x2EFFFFFF, 0x0FFFFFFF))
        bg.cornerRadius = dp(26).toFloat()
        bg.setStroke(dp(1), 0x30FFFFFF)
        box.background = bg

        val img = ImageView(this)
        img.setImageResource(w.iconRes)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        val pad = (size * 0.13f).toInt()
        img.setPadding(pad, pad, pad, pad)
        box.addView(img, FrameLayout.LayoutParams(size, size))
        tile.addView(box, LinearLayout.LayoutParams(size, size))

        val label = TextView(this)
        label.text = w.label
        label.textSize = 12f
        label.setTextColor(0xE6FFFFFF.toInt())
        label.gravity = Gravity.CENTER
        label.maxLines = 1
        label.ellipsize = TextUtils.TruncateAt.END
        val lLp = LinearLayout.LayoutParams(size, ViewGroup.LayoutParams.WRAP_CONTENT)
        lLp.topMargin = dp(7)
        tile.addView(label, lLp)

        tile.setOnClickListener { openWidget(w) }
        tile.setOnLongClickListener { showPicker(w, false); true }
        tile.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(90).start()
            } else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }

        tile.alpha = 0f
        tile.translationY = dp(24).toFloat()
        var delay = index * 25L
        if (delay > 600L) delay = 600L
        tile.animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(380)
            .setInterpolator(DecelerateInterpolator()).start()
        return tile
    }

    private fun openWidget(w: WidgetDef) {
        val saved = prefs.getString("pkg_" + w.id, null)
        val list: List<String> = if (saved != null) listOf(saved) else w.candidates
        for (c in list) {
            val intent: Intent? = if (c.startsWith("action:")) {
                Intent(c.removePrefix("action:"))
            } else {
                packageManager.getLaunchIntentForPackage(c)
            }
            if (intent != null) {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                try {
                    startActivity(intent)
                    return
                } catch (e: Exception) {
                    // try next candidate
                }
            }
        }
        Toast.makeText(this, "Choose an app for " + w.label, Toast.LENGTH_SHORT).show()
        showPicker(w, true)
    }

    private fun showPicker(w: WidgetDef, launchAfter: Boolean) {
        val pm = packageManager
        val main = Intent(Intent.ACTION_MAIN)
        main.addCategory(Intent.CATEGORY_LAUNCHER)
        val apps: List<ResolveInfo> = pm.queryIntentActivities(main, 0)
            .filter { it.activityInfo.packageName != packageName }
            .distinctBy { it.activityInfo.packageName }
            .sortedBy { it.loadLabel(pm).toString().lowercase() }

        val adapter = object : BaseAdapter() {
            override fun getCount(): Int = apps.size
            override fun getItem(position: Int): Any = apps[position]
            override fun getItemId(position: Int): Long = position.toLong()
            override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
                val ctx = this@MainActivity
                val row = LinearLayout(ctx)
                row.orientation = LinearLayout.HORIZONTAL
                row.gravity = Gravity.CENTER_VERTICAL
                row.setPadding(dp(18), dp(8), dp(18), dp(8))
                val icon = ImageView(ctx)
                icon.setImageDrawable(apps[position].loadIcon(pm))
                row.addView(icon, LinearLayout.LayoutParams(dp(40), dp(40)))
                val tv = TextView(ctx)
                tv.text = apps[position].loadLabel(pm).toString()
                tv.textSize = 16f
                tv.setTextColor(Color.WHITE)
                tv.setPadding(dp(14), 0, 0, 0)
                row.addView(tv, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
                return row
            }
        }

        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setTitle(w.label)
            .setAdapter(adapter) { _, which ->
                prefs.edit().putString("pkg_" + w.id, apps[which].activityInfo.packageName).apply()
                if (launchAfter) openWidget(w)
            }
            .setNeutralButton("Default") { _, _ ->
                prefs.edit().remove("pkg_" + w.id).apply()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }
}

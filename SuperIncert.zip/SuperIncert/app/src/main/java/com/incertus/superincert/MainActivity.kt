package com.incertus.superincert

import android.app.Activity
import android.app.AlertDialog
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.animation.DecelerateInterpolator
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var prefs: SharedPreferences

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("superincert", Context.MODE_PRIVATE)
        window.statusBarColor = 0xFF0B1030.toInt()
        window.navigationBarColor = 0xFF0A0E2A.toInt()
        setContentView(buildUi())
    }

    private fun buildUi(): View {
        val root = FrameLayout(this)

        val scroll = ScrollView(this)
        scroll.isVerticalScrollBarEnabled = false
        scroll.overScrollMode = View.OVER_SCROLL_NEVER

        val col = LinearLayout(this)
        col.orientation = LinearLayout.VERTICAL
        col.gravity = Gravity.CENTER_HORIZONTAL
        col.setPadding(dp(16), dp(26), dp(16), dp(100))
        scroll.addView(col, ViewGroup.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))

        // ---- Header ----
        val title = TextView(this)
        title.text = "SuperIncert"
        title.textSize = 38f
        title.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        title.setTextColor(Color.WHITE)
        title.post {
            val wd = title.width.toFloat()
            if (wd > 0f) {
                title.paint.shader = LinearGradient(
                    0f, 0f, wd, 0f,
                    intArrayOf(0xFF8AB4FF.toInt(), 0xFFC58BFF.toInt(), 0xFFFF8AD8.toInt()),
                    null, Shader.TileMode.CLAMP
                )
                title.invalidate()
            }
        }
        col.addView(title, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val chip = TextView(this)
        chip.text = "by Incertus"
        chip.textSize = 13f
        chip.letterSpacing = 0.08f
        chip.setTextColor(0xFFDCE3FF.toInt())
        chip.setPadding(dp(14), dp(5), dp(14), dp(5))
        val chipBg = GradientDrawable()
        chipBg.cornerRadius = dp(20).toFloat()
        chipBg.setColor(0x26FFFFFF)
        chipBg.setStroke(dp(1), 0x40FFFFFF)
        chip.background = chipBg
        val chipLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        chipLp.topMargin = dp(6)
        col.addView(chip, chipLp)

        val info = TextView(this)
        info.text = "اضغط على الويدجيت  \u2022  اختر شكله  \u2022  ثم اختر تطبيقه"
        info.textSize = 12f
        info.setTextColor(0x99FFFFFF.toInt())
        info.gravity = Gravity.CENTER
        val infoLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        infoLp.topMargin = dp(14)
        infoLp.bottomMargin = dp(18)
        col.addView(info, infoLp)

        // ---- Grid: 3 equal square tiles per row ----
        val screenW = resources.displayMetrics.widthPixels
        val slot = (screenW - dp(32)) / 3
        val size = slot - dp(12)
        var i = 0
        while (i < GROUPS.size) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (k in 0 until 3) {
                val idx = i + k
                val cell: View = if (idx < GROUPS.size) makeTile(GROUPS[idx], size, idx) else View(this)
                row.addView(cell, LinearLayout.LayoutParams(slot, ViewGroup.LayoutParams.WRAP_CONTENT))
            }
            col.addView(row, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))
            i += 3
        }

        // ---- About button (floating, bottom) ----
        val about = TextView(this)
        about.text = "حول"
        about.textSize = 15f
        about.typeface = Typeface.DEFAULT_BOLD
        about.setTextColor(Color.WHITE)
        about.gravity = Gravity.CENTER
        about.setPadding(dp(44), dp(12), dp(44), dp(12))
        val aboutBg = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xFF7B5CFF.toInt(), 0xFF18C8E8.toInt())
        )
        aboutBg.cornerRadius = dp(28).toFloat()
        about.background = aboutBg
        about.elevation = dp(8).toFloat()
        about.setOnClickListener { showAbout() }
        val aLp = FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        aLp.gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
        aLp.bottomMargin = dp(22)
        root.addView(about, aLp)

        return root
    }

    private fun makeTile(g: WidgetGroup, size: Int, index: Int): View {
        val tile = LinearLayout(this)
        tile.orientation = LinearLayout.VERTICAL
        tile.gravity = Gravity.CENTER_HORIZONTAL
        tile.setPadding(dp(6), 0, dp(6), dp(12))

        val box = FrameLayout(this)
        val img = ImageView(this)
        img.setImageResource(g.shapes[0].iconRes)
        img.scaleType = ImageView.ScaleType.FIT_CENTER
        val pad = (size * 0.06f).toInt()
        img.setPadding(pad, pad, pad, pad)
        box.addView(img, FrameLayout.LayoutParams(size, size))

        tile.addView(box, LinearLayout.LayoutParams(size, size))

        tile.setOnClickListener { showShapeChooser(g) }
        tile.setOnTouchListener { v, e ->
            if (e.action == MotionEvent.ACTION_DOWN) {
                v.animate().scaleX(0.93f).scaleY(0.93f).setDuration(90).start()
            } else if (e.action == MotionEvent.ACTION_UP || e.action == MotionEvent.ACTION_CANCEL) {
                v.animate().scaleX(1f).scaleY(1f).setDuration(140).start()
            }
            false
        }

        tile.alpha = 0f
        tile.translationY = dp(24).toFloat()
        var delay = index * 25L
        if (delay > 600L) delay = 600L
        tile.animate().alpha(1f).translationY(0f).setStartDelay(delay).setDuration(380)
            .setInterpolator(DecelerateInterpolator()).start()
        return tile
    }

    /** 1) choose the shape  2) choose the app  3) the widget is sent to the home screen. */
    private fun showShapeChooser(g: WidgetGroup) {
        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.setPadding(dp(16), dp(20), dp(16), dp(8))

        val dlg = AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setView(root)
            .setNegativeButton("إلغاء", null)
            .create()

        val ttl = TextView(this)
        ttl.text = "اختر شكل الويدجيت"
        ttl.textSize = 17f
        ttl.typeface = Typeface.DEFAULT_BOLD
        ttl.setTextColor(Color.WHITE)
        ttl.gravity = Gravity.CENTER
        root.addView(ttl, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT))

        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        val rLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        rLp.topMargin = dp(16)
        root.addView(row, rLp)

        for (s in g.shapes) {
            val card = FrameLayout(this)
            val bg = GradientDrawable(GradientDrawable.Orientation.TL_BR, intArrayOf(0x2EFFFFFF, 0x0FFFFFFF))
            bg.cornerRadius = dp(18).toFloat()
            bg.setStroke(dp(1), 0x30FFFFFF)
            card.background = bg
            val iv = ImageView(this)
            iv.setImageResource(s.iconRes)
            iv.scaleType = ImageView.ScaleType.FIT_CENTER
            iv.setPadding(dp(10), dp(10), dp(10), dp(10))
            card.addView(iv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
            card.setOnClickListener {
                dlg.dismiss()
                chooseApp(g, s)
            }
            val weight: Float = if (s.shape == "pill") 1.5f else if (s.shape == "vertical") 0.7f else 1f
            val lp = LinearLayout.LayoutParams(0, dp(150), weight)
            lp.setMargins(dp(4), 0, dp(4), 0)
            row.addView(card, lp)
        }
        dlg.show()
    }

    private fun chooseApp(g: WidgetGroup, s: WidgetShape) {
        AppPicker.show(this, s.iconRes, { pkg ->
            WidgetUtil.setPending(this, s.key, pkg)
            pinWidget(s)
        }, { })
    }

    private fun pinWidget(s: WidgetShape) {
        val mgr = AppWidgetManager.getInstance(this)
        if (mgr.isRequestPinAppWidgetSupported) {
            val cn = ComponentName(packageName, "com.incertus.superincert.W_" + s.key)
            mgr.requestPinAppWidget(cn, null, null)
        } else {
            AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
                .setTitle("أضفه يدويًا")
                .setMessage("شاشتك الرئيسية لا تدعم الإضافة المباشرة.\n\nاضغط مطولًا على الشاشة الرئيسية \u2190 الويدجيتس \u2190 SuperIncert، ثم اسحب هذا الويدجيت. التطبيق الذي اخترته سيُربط به تلقائيًا.")
                .setPositiveButton("حسنًا", null)
                .show()
        }
    }

    private fun infoRow(k: String, v: String): View {
        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.setPadding(dp(14), dp(11), dp(14), dp(11))
        val bg = GradientDrawable()
        bg.cornerRadius = dp(14).toFloat()
        bg.setColor(0x1AFFFFFF)
        r.background = bg
        val a = TextView(this)
        a.text = k
        a.textSize = 14f
        a.setTextColor(0xB3FFFFFF.toInt())
        val b = TextView(this)
        b.text = v
        b.textSize = 14f
        b.typeface = Typeface.DEFAULT_BOLD
        b.setTextColor(Color.WHITE)
        b.gravity = Gravity.END
        r.addView(a, LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT))
        r.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        return r
    }

    private fun showAbout() {
        var ver = "1.0"
        try {
            val v = packageManager.getPackageInfo(packageName, 0).versionName
            if (v != null) ver = v
        } catch (e: Exception) {
        }

        val root = LinearLayout(this)
        root.orientation = LinearLayout.VERTICAL
        root.gravity = Gravity.CENTER_HORIZONTAL
        root.setPadding(dp(22), dp(22), dp(22), dp(8))

        val logo = ImageView(this)
        logo.setImageResource(R.mipmap.ic_launcher)
        root.addView(logo, LinearLayout.LayoutParams(dp(72), dp(72)))

        val name = TextView(this)
        name.text = "SuperIncert"
        name.textSize = 24f
        name.typeface = Typeface.create("sans-serif-black", Typeface.NORMAL)
        name.setTextColor(Color.WHITE)
        val nLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        nLp.topMargin = dp(10)
        root.addView(name, nLp)

        val sub = TextView(this)
        sub.text = "ويدجيتس بتصميم HyperOS لشاشتك الرئيسية"
        sub.textSize = 13f
        sub.gravity = Gravity.CENTER
        sub.setTextColor(0xB3FFFFFF.toInt())
        val sLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        sLp.topMargin = dp(4)
        sLp.bottomMargin = dp(14)
        root.addView(sub, sLp)

        val rows = listOf(
            infoRow("الإصدار", ver),
            infoRow("المطوّر", "Incertus"),
            infoRow("يعمل على", "Android 8.0+")
        )
        for (r in rows) {
            val lp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
            lp.topMargin = dp(8)
            root.addView(r, lp)
        }

        val tg = TextView(this)
        tg.text = "قناة التليجرام  \u2022  @Incert_us"
        tg.textSize = 15f
        tg.typeface = Typeface.DEFAULT_BOLD
        tg.setTextColor(Color.WHITE)
        tg.gravity = Gravity.CENTER
        tg.setPadding(dp(16), dp(13), dp(16), dp(13))
        val tgBg = GradientDrawable(
            GradientDrawable.Orientation.LEFT_RIGHT,
            intArrayOf(0xFF2AABEE.toInt(), 0xFF229ED9.toInt())
        )
        tgBg.cornerRadius = dp(16).toFloat()
        tg.background = tgBg
        tg.setOnClickListener {
            try {
                startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/Incert_us")))
            } catch (e: Exception) {
                Toast.makeText(this, "تعذّر فتح الرابط", Toast.LENGTH_SHORT).show()
            }
        }
        val tgLp = LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT)
        tgLp.topMargin = dp(16)
        root.addView(tg, tgLp)

        AlertDialog.Builder(this, android.R.style.Theme_DeviceDefault_Dialog_Alert)
            .setView(root)
            .setPositiveButton("إغلاق", null)
            .show()
    }
}

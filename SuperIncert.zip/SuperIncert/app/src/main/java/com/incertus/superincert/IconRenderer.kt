package com.incertus.superincert

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.Rect
import android.graphics.RectF

/**
 * Draws a widget icon at the exact size the user gave the widget.
 * Rounded caps and the central glyph keep their proportions; only the plain
 * background strips between them are stretched, so the shape grows like a real widget.
 * It also picks the shape of the group (square / pill / vertical) that fills the area best.
 */
object IconRenderer {

    private class Piece(val a: Int, val b: Int, val stretch: Boolean)

    private class Plan(
        val shape: WidgetShape,
        val xps: List<Piece>,
        val yps: List<Piece>,
        val s: Float,
        val area: Float
    )

    private fun pieces(len: Int, cap: Int, g0: Int, g1: Int): List<Piece> {
        val l = ArrayList<Piece>()
        if (g0 - cap >= 8 && (len - cap) - g1 >= 8) {
            l.add(Piece(0, cap, false))
            l.add(Piece(cap, g0, true))
            l.add(Piece(g0, g1, false))
            l.add(Piece(g1, len - cap, true))
            l.add(Piece(len - cap, len, false))
        } else {
            l.add(Piece(0, len, false))
        }
        return l
    }

    private fun hasStretch(ps: List<Piece>): Boolean = ps.size > 1

    private fun fixedLen(ps: List<Piece>): Int {
        var f = 0
        for (p in ps) {
            if (!p.stretch) f += p.b - p.a
        }
        return f
    }

    private fun bound(ps: List<Piece>, target: Int): Float {
        val total = ps[ps.size - 1].b
        return if (hasStretch(ps)) target.toFloat() / fixedLen(ps) else target.toFloat() / total
    }

    private fun plan(sh: WidgetShape, tw: Int, th: Int): Plan {
        val xps = pieces(sh.w, sh.cap, sh.gx0, sh.gx1)
        val yps = pieces(sh.h, sh.cap, sh.gy0, sh.gy1)
        var s = Math.min(bound(xps, tw), bound(yps, th))
        if (s > 1.25f) s = 1.25f
        val ow = if (hasStretch(xps)) tw.toFloat() else sh.w * s
        val oh = if (hasStretch(yps)) th.toFloat() else sh.h * s
        return Plan(sh, xps, yps, s, ow * oh)
    }

    private fun layoutAxis(ps: List<Piece>, target: Int, s: Float): FloatArray {
        val out = FloatArray(ps.size + 1)
        var stretchCount = 0
        var fixed = 0f
        for (p in ps) {
            if (p.stretch) stretchCount++ else fixed += (p.b - p.a) * s
        }
        var start = 0f
        var share = 0f
        if (stretchCount > 0) {
            share = Math.max(0f, (target - fixed) / stretchCount)
        } else {
            start = (target - fixed) / 2f
        }
        out[0] = start
        var pos = start
        for (i in ps.indices) {
            val p = ps[i]
            pos += if (p.stretch) share else (p.b - p.a) * s
            out[i + 1] = pos
        }
        return out
    }

    private fun scaleBitmap(src: Bitmap, tw: Int, th: Int): Bitmap {
        var cur = src
        while (cur.width / 2 >= tw && cur.height / 2 >= th) {
            val n = Bitmap.createScaledBitmap(cur, cur.width / 2, cur.height / 2, true)
            if (cur !== src) cur.recycle()
            cur = n
        }
        val out = Bitmap.createScaledBitmap(cur, tw, th, true)
        if (cur !== src && cur !== out) cur.recycle()
        return out
    }

    fun render(c: Context, shape: WidgetShape, tw: Int, th: Int): Bitmap {
        val candidates = ArrayList<WidgetShape>()
        candidates.add(shape)
        for (g in GROUPS) {
            for (s in g.shapes) {
                if (s.key == shape.key) {
                    for (o in g.shapes) {
                        if (o.key != shape.key) candidates.add(o)
                    }
                }
            }
        }
        var best: Plan = plan(candidates[0], tw, th)
        for (i in 1 until candidates.size) {
            val p = plan(candidates[i], tw, th)
            if (p.area > best.area * 1.03f) best = p
        }

        val opts = BitmapFactory.Options()
        opts.inScaled = false
        val src = BitmapFactory.decodeResource(c.resources, best.shape.iconRes, opts)
        val sw = Math.max(1, Math.round(best.shape.w * best.s))
        val sh = Math.max(1, Math.round(best.shape.h * best.s))
        val scaled = scaleBitmap(src, sw, sh)

        val out = Bitmap.createBitmap(tw, th, Bitmap.Config.ARGB_8888)
        val cv = Canvas(out)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
        val xd = layoutAxis(best.xps, tw, best.s)
        val yd = layoutAxis(best.yps, th, best.s)
        for (yi in best.yps.indices) {
            val yp = best.yps[yi]
            for (xi in best.xps.indices) {
                val xp = best.xps[xi]
                val sr = Rect(
                    Math.round(xp.a * best.s), Math.round(yp.a * best.s),
                    Math.round(xp.b * best.s), Math.round(yp.b * best.s)
                )
                if (sr.width() <= 0 || sr.height() <= 0) continue
                val dr = RectF(xd[xi], yd[yi], xd[xi + 1] + 0.6f, yd[yi + 1] + 0.6f)
                cv.drawBitmap(scaled, sr, dr, paint)
            }
        }
        return out
    }
}

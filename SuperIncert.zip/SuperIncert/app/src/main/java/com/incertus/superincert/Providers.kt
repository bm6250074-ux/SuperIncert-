package com.incertus.superincert

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context

open class IconWidgetProvider(private val typeId: String) : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            WidgetUtil.bindPending(context, typeId, id)
            WidgetUtil.update(context, appWidgetManager, id)
        }
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        WidgetUtil.forget(context, appWidgetIds)
    }
}

class W_phone : IconWidgetProvider("phone")
class W_messages : IconWidgetProvider("messages")
class W_camera : IconWidgetProvider("camera")
class W_gallery : IconWidgetProvider("gallery")
class W_browser : IconWidgetProvider("browser")
class W_google : IconWidgetProvider("google")
class W_play : IconWidgetProvider("play")
class W_settings : IconWidgetProvider("settings")
class W_assistant : IconWidgetProvider("assistant")
class W_mail : IconWidgetProvider("mail")
class W_calendar : IconWidgetProvider("calendar")
class W_clock : IconWidgetProvider("clock")
class W_calc : IconWidgetProvider("calc")
class W_notes : IconWidgetProvider("notes")
class W_quicknote : IconWidgetProvider("quicknote")
class W_files : IconWidgetProvider("files")
class W_download : IconWidgetProvider("download")
class W_music : IconWidgetProvider("music")
class W_video : IconWidgetProvider("video")
class W_vlc : IconWidgetProvider("vlc")
class W_recorder : IconWidgetProvider("recorder")
class W_scanner : IconWidgetProvider("scanner")
class W_weather : IconWidgetProvider("weather")
class W_weather2 : IconWidgetProvider("weather2")
class W_battery : IconWidgetProvider("battery")
class W_memory : IconWidgetProvider("memory")
class W_cleaner : IconWidgetProvider("cleaner")
class W_security : IconWidgetProvider("security")
class W_transfer : IconWidgetProvider("transfer")
class W_wallet : IconWidgetProvider("wallet")
class W_store : IconWidgetProvider("store")
class W_telegram : IconWidgetProvider("telegram")
class W_box : IconWidgetProvider("box")
class W_ring : IconWidgetProvider("ring")
class W_help : IconWidgetProvider("help")

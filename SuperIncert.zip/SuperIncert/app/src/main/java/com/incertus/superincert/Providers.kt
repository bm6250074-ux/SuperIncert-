package com.incertus.superincert

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.os.Bundle

open class IconWidgetProvider(private val typeId: String) : AppWidgetProvider() {
    override fun onUpdate(context: Context, appWidgetManager: AppWidgetManager, appWidgetIds: IntArray) {
        for (id in appWidgetIds) {
            WidgetUtil.bindPending(context, typeId, id)
            WidgetUtil.update(context, appWidgetManager, id)
        }
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, appWidgetManager: AppWidgetManager, appWidgetId: Int, newOptions: Bundle
    ) {
        WidgetUtil.update(context, appWidgetManager, appWidgetId)
    }

    override fun onDeleted(context: Context, appWidgetIds: IntArray) {
        WidgetUtil.forget(context, appWidgetIds)
    }
}

class W_phone_green_square_square : IconWidgetProvider("phone_green_square_square")
class W_phone_green_square_pill : IconWidgetProvider("phone_green_square_pill")
class W_phone_green_square_vertical : IconWidgetProvider("phone_green_square_vertical")
class W_phone_green_circle_square : IconWidgetProvider("phone_green_circle_square")
class W_phone_green_circle_pill : IconWidgetProvider("phone_green_circle_pill")
class W_phone_green_circle_vertical : IconWidgetProvider("phone_green_circle_vertical")
class W_phone_green_circle2_square : IconWidgetProvider("phone_green_circle2_square")
class W_phone_green_circle2_pill : IconWidgetProvider("phone_green_circle2_pill")
class W_phone_green_circle2_vertical : IconWidgetProvider("phone_green_circle2_vertical")
class W_messages_green_square : IconWidgetProvider("messages_green_square")
class W_messages_green_pill : IconWidgetProvider("messages_green_pill")
class W_messages_green_vertical : IconWidgetProvider("messages_green_vertical")
class W_contacts_gray_a_square : IconWidgetProvider("contacts_gray_a_square")
class W_contacts_gray_a_pill : IconWidgetProvider("contacts_gray_a_pill")
class W_contacts_gray_a_vertical : IconWidgetProvider("contacts_gray_a_vertical")
class W_home_blue_square : IconWidgetProvider("home_blue_square")
class W_home_blue_pill : IconWidgetProvider("home_blue_pill")
class W_home_blue_vertical : IconWidgetProvider("home_blue_vertical")
class W_apps_blue_square : IconWidgetProvider("apps_blue_square")
class W_apps_blue_pill : IconWidgetProvider("apps_blue_pill")
class W_apps_blue_vertical : IconWidgetProvider("apps_blue_vertical")
class W_apps_orange_circle_square : IconWidgetProvider("apps_orange_circle_square")
class W_apps_orange_circle_pill : IconWidgetProvider("apps_orange_circle_pill")
class W_apps_orange_circle_vertical : IconWidgetProvider("apps_orange_circle_vertical")
class W_store_orange_square : IconWidgetProvider("store_orange_square")
class W_store_orange_pill : IconWidgetProvider("store_orange_pill")
class W_store_orange_vertical : IconWidgetProvider("store_orange_vertical")
class W_download_blue_square : IconWidgetProvider("download_blue_square")
class W_download_blue_pill : IconWidgetProvider("download_blue_pill")
class W_download_blue_vertical : IconWidgetProvider("download_blue_vertical")
class W_gallery_flower_square : IconWidgetProvider("gallery_flower_square")
class W_gallery_flower_pill : IconWidgetProvider("gallery_flower_pill")
class W_gallery_flower_vertical : IconWidgetProvider("gallery_flower_vertical")
class W_flower_pink_square : IconWidgetProvider("flower_pink_square")
class W_flower_pink_pill : IconWidgetProvider("flower_pink_pill")
class W_flower_pink_vertical : IconWidgetProvider("flower_pink_vertical")
class W_music_green_square : IconWidgetProvider("music_green_square")
class W_music_green_pill : IconWidgetProvider("music_green_pill")
class W_music_green_vertical : IconWidgetProvider("music_green_vertical")
class W_music_teal_square : IconWidgetProvider("music_teal_square")
class W_music_teal_pill : IconWidgetProvider("music_teal_pill")
class W_music_teal_vertical : IconWidgetProvider("music_teal_vertical")
class W_notes_red_square : IconWidgetProvider("notes_red_square")
class W_notes_red_pill : IconWidgetProvider("notes_red_pill")
class W_notes_red_vertical : IconWidgetProvider("notes_red_vertical")
class W_todo_blue_check_square : IconWidgetProvider("todo_blue_check_square")
class W_todo_blue_check_pill : IconWidgetProvider("todo_blue_check_pill")
class W_todo_blue_check_vertical : IconWidgetProvider("todo_blue_check_vertical")
class W_todo_blue_check2_square : IconWidgetProvider("todo_blue_check2_square")
class W_todo_blue_check2_pill : IconWidgetProvider("todo_blue_check2_pill")
class W_todo_blue_check2_vertical : IconWidgetProvider("todo_blue_check2_vertical")
class W_lock_green_square : IconWidgetProvider("lock_green_square")
class W_lock_green_pill : IconWidgetProvider("lock_green_pill")
class W_lock_green_vertical : IconWidgetProvider("lock_green_vertical")
class W_stats_red_square : IconWidgetProvider("stats_red_square")
class W_stats_red_pill : IconWidgetProvider("stats_red_pill")
class W_stats_red_vertical : IconWidgetProvider("stats_red_vertical")
class W_link_orange_square : IconWidgetProvider("link_orange_square")
class W_link_orange_pill : IconWidgetProvider("link_orange_pill")
class W_link_orange_vertical : IconWidgetProvider("link_orange_vertical")
class W_clips_purple_square : IconWidgetProvider("clips_purple_square")
class W_clips_purple_pill : IconWidgetProvider("clips_purple_pill")
class W_clips_purple_vertical : IconWidgetProvider("clips_purple_vertical")
class W_ai_gradient_a_square : IconWidgetProvider("ai_gradient_a_square")
class W_ai_gradient_a_pill : IconWidgetProvider("ai_gradient_a_pill")
class W_ai_gradient_a_vertical : IconWidgetProvider("ai_gradient_a_vertical")
class W_ai_purple_sparkle_square : IconWidgetProvider("ai_purple_sparkle_square")
class W_ai_purple_sparkle_pill : IconWidgetProvider("ai_purple_sparkle_pill")
class W_ai_purple_sparkle_vertical : IconWidgetProvider("ai_purple_sparkle_vertical")
class W_ai_red_sparkle_square : IconWidgetProvider("ai_red_sparkle_square")
class W_ai_red_sparkle_pill : IconWidgetProvider("ai_red_sparkle_pill")
class W_ai_red_sparkle_vertical : IconWidgetProvider("ai_red_sparkle_vertical")
class W_themes_rainbow_square : IconWidgetProvider("themes_rainbow_square")
class W_themes_rainbow_pill : IconWidgetProvider("themes_rainbow_pill")
class W_themes_rainbow_vertical : IconWidgetProvider("themes_rainbow_vertical")
class W_themes_orange_purple_square : IconWidgetProvider("themes_orange_purple_square")
class W_themes_orange_purple_pill : IconWidgetProvider("themes_orange_purple_pill")
class W_themes_orange_purple_vertical : IconWidgetProvider("themes_orange_purple_vertical")
class W_wallpaper_pink_brush_square : IconWidgetProvider("wallpaper_pink_brush_square")
class W_wallpaper_pink_brush_pill : IconWidgetProvider("wallpaper_pink_brush_pill")
class W_wallpaper_pink_brush_vertical : IconWidgetProvider("wallpaper_pink_brush_vertical")
class W_wand_purple_square : IconWidgetProvider("wand_purple_square")
class W_wand_purple_pill : IconWidgetProvider("wand_purple_pill")
class W_wand_purple_vertical : IconWidgetProvider("wand_purple_vertical")
class W_triangle_green_square : IconWidgetProvider("triangle_green_square")
class W_triangle_green_pill : IconWidgetProvider("triangle_green_pill")
class W_triangle_green_vertical : IconWidgetProvider("triangle_green_vertical")
